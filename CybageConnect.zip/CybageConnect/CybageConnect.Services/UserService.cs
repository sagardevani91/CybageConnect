﻿using CybageConnect.Entity.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services
{
    public class UserService : IUserService
    {
        private readonly CybageConnectContext _context;
        public UserService(CybageConnectContext context) 
        {
            _context = context;
        }

        public void Login()
        {
            Console.Write("Enter your username: ");
            string username = Console.ReadLine();
            Console.Write("Enter your password: ");
            string password = Console.ReadLine();

            var user = _context.Users.FirstOrDefault(u => u.UserName == username && u.Password == password);

            if (user != null)
            {
                Console.WriteLine("Login successful! Welcome, " + user.FirstName + "!");
                // Proceed to user's profile dashboard
            }
            else
            {
                Console.WriteLine("Invalid username or password. Please try again.");
            }
        }

        public void Register()
        {
            Console.WriteLine("Please enter the following details to register:");
            Console.Write("Name: ");
            string name = Console.ReadLine();
            Console.Write("Username: ");
            string username = Console.ReadLine();
            Console.Write("Password: ");
            string password = Console.ReadLine();
            Console.Write("Email Address: ");
            string email = Console.ReadLine();
            Console.Write("Phone Number: ");
            string phoneNumber = Console.ReadLine();

            if (_context.Users.Any(u => u.UserName == username))
            {
                Console.WriteLine("Username already exists. Please choose a different one.");
                return;
            }

            if (_context.Users.Any(u => u.Email == email))
            {
                Console.WriteLine("Email Address already exists. Please choose a different one.");
                return;
            }

            if (_context.Users.Any(u => u.Phone == phoneNumber))
            {
                Console.WriteLine("Phone Number already exists. Please choose a different one.");
                return;
            }

            // Auto-generate UserID

            User newUser = new User
            {
                FirstName = name, 
                LastName = name,
                UserName = username, 
                Password =password, 
                Email = email, 
                Phone = phoneNumber
            };
                
            _context.Users.Add(newUser);
            _context.SaveChanges();

            Console.WriteLine("Registration successful! Your UserID is: ");
        }

    }
}
