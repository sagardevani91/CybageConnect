﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services
{

    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepo;
   

        public UserService(IUserRepository userRepo) 
        {
            _userRepo = userRepo;
        }

        public bool ValidateUser(string username, string password)
        {
            return _userRepo.ValidateUser(username, password); 
        }

        public void Register(string? name, string? username, string? password, string? email, string? phoneNumber)
        {
            User newUser = new User
            {
                FirstName = name,
                LastName = name,
                UserName = username,
                Password = password,
                Email = email,
                Phone = phoneNumber
            };
            _userRepo.RegisterUser(newUser);
        }

        public void FindUser(int id)
        {
            _userRepo.FindUser(id);
        }
    }
}
