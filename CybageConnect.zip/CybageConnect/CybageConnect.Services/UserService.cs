﻿using Azure.Identity;
using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services
{

    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepo;
   

        public UserService(IUserRepository userRepo) 
        {
            _userRepo = userRepo;
        }

        public User ValidateUser(string username, string password)
        {
            return _userRepo.ValidateUser(username, password); 
        }

        public bool Register(string name, string username, string password, string email, string phoneNumber)
        {
            User newUser = new User
            {
                FirstName = name,
                LastName = name,
                UserName = username,
                Password = password,
                Email = email,
                Phone = phoneNumber
            };
            int? record = _userRepo.RegisterUser(newUser);
            if(record > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void UpdateUser(User user,string name,string email,string phone)
        {
            _userRepo.UpdateUser(user,name,email,phone);
        }

        public List<User> GetAllUsers(User loggedUser) 
        {
            return _userRepo.GetAllUsers(loggedUser);
        }

        public User GetUserByName(string username)
        {
            return _userRepo.GetUserByName(username);
        }

        public bool RequestConnection(User loggedUser, User requestedUser)
        {
            Connection conn = new Connection
            {
                UserSendId = loggedUser.Id,
                UserAcceptId = requestedUser.Id,
                ConnectionStatus = 0,
                ConnectionDate = DateTime.Now,
            };
            int? record = _userRepo.RequestConnection(conn);
            return (record > 0) ? true : false;
        }

        public List<User> GetAllPendingUsers(User loggedUser)
        {
            return _userRepo.GetAllPendingUsers(loggedUser);
        }
        public void AcceptUser(User loggedUser, User requestedUser)
        {
            _userRepo.AcceptUser(loggedUser, requestedUser);
        }
        public void RejectUser(User loggedUser, User requestedUser)
        {
            _userRepo.RejectUser(loggedUser, requestedUser);
        }
        public List<User> GetConnectedUsers(User loggedUser)
        {
            return _userRepo.GetConnectedUsers(loggedUser);
        }
    }
}
