﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services
{
    public interface IUserService
    {
        bool ValidateUser(string username,string password);
        void Register(string? name, string? username, string? password, string? email, string? phoneNumber);

        void FindUser(int id);
    }
}
