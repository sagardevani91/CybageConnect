﻿using CybageConnect.Entity.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services
{
    public interface IUserService
    {
        User ValidateUser(string username,string password);
        bool Register(string? name, string? username, string? password, string? email, string? phoneNumber);

        void UpdateUser(User user, string name, string email, string phone);

        List<User> GetAllUsers(User loddedUser);

        User GetUserByName(string username);
        bool RequestConnection(User loddedUser, User requestedUser);
        List<User> GetAllPendingUsers(User loggedUser);

        void AcceptUser(User loddedUser, User requestedUser);
        void RejectUser(User loddedUser, User requestedUser);

        List<User> GetConnectedUsers(User loddedUser);
    }
}
