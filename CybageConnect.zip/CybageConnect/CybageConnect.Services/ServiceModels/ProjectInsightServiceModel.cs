﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services.ServiceModels
{
    public class ProjectInsightServiceModel
    {
        public int Id { get; set; }

        public string ProjectName { get; set; } = null!;

        public string ProjectInsight1 { get; set; } = null!;

        public DateTime InsightDate { get; set; }

        public int UserId { get; set; }
    }
}
