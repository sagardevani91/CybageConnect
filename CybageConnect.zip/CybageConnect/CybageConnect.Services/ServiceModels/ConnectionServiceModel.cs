﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services.ServiceModels
{
    public class ConnectionServiceModel
    {
        public int Id { get; set; }

        public int UserSendId { get; set; }

        public int UserAcceptId { get; set; }

        public int ConnectionStatus { get; set; }

        public DateTime ConnectionDate { get; set; }
    }
}
