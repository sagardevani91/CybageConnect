﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services.ServiceModels
{
    public class BlogServiceModel
    {
        public int Id { get; set; }

        public string BlogName { get; set; } = null!;

        public string BlogContent { get; set; } = null!;

        public DateTime BlogDate { get; set; }

        public int UserId { get; set; }
    }
}
