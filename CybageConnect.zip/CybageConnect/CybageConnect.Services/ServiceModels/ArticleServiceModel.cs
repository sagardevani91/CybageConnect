﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services.ServiceModels
{
    public class ArticleServiceModel
    {
        public int Id { get; set; }

        public string ArticleName { get; set; } = null!;

        public string ArticleContent { get; set; } = null!;

        public DateTime ArticleDate { get; set; }

        public int UserId { get; set; }
    }
}
