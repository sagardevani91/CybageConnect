﻿using CybageConnect.Entity.DB;
using CybageConnect.Services.ServiceModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services.Services.Iservices
{
    public interface IKnowledgeSharingService
    {
        bool AddBlogs(string? blogname, string? blogcontent, DateTime? blogdate, UserServiceModel loggedUser);
        List<BlogServiceModel> GetBlogs();

        bool AddArticles(string? articlename, string? articlecontent, DateTime? articledate, UserServiceModel loggedUser);

        List<ArticleServiceModel> GetArticles();
        bool AddProjectInsights(string? projectname, string? projectinsight1, DateTime? insightdate, UserServiceModel loggedUser);

        List<ProjectInsightServiceModel> GetProjectInsights();
    }
}
