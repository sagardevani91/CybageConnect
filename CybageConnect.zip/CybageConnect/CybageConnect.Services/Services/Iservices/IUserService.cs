﻿using CybageConnect.Entity.DB;
using CybageConnect.Services.ServiceModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services.Services.Iservices
{
    public interface IUserService
    {
        UserServiceModel ValidateUser(string username, string password);
        bool Register(string? fname, string lname, string? username, string? password, string? email, string? phoneNumber);

        bool UpdateUser(UserServiceModel user, string name, string email, string phone);

        List<UserServiceModel> GetAllUsers(UserServiceModel loddedUser);

        UserServiceModel GetUserByName(string username);
        bool RequestConnection(UserServiceModel loddedUser, UserServiceModel requestedUser);
        List<UserServiceModel> GetAllPendingUsers(UserServiceModel loggedUser);

        bool AcceptUser(UserServiceModel loddedUser, UserServiceModel requestedUser);
        bool RejectUser(UserServiceModel loddedUser, UserServiceModel requestedUser);

        List<UserServiceModel> GetConnectedUsers(UserServiceModel loddedUser);
    }
}
