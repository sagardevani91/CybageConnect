﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using CybageConnect.Services.ServiceModels;
using CybageConnect.Services.Services.Iservices;

namespace CybageConnect.Services.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepo;


        public UserService(IUserRepository userRepo)
        {
            _userRepo = userRepo;
        }


        private UserServiceModel ConvertUserToUserServiceModel(User user)
        {
            UserServiceModel userServiceModel = new UserServiceModel()
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                UserName = user.UserName,
                Password = user.Password,
                Email = user.Email,
                Phone = user.Phone,
                IsActive = user.IsActive,
            };
            return userServiceModel;
        }

        private User ConvertUserServiceModelToUser(UserServiceModel userServiceModel)
        {
            User user = new User()
            {
                Id = userServiceModel.Id,
                FirstName = userServiceModel.FirstName,
                LastName = userServiceModel.LastName,
                UserName = userServiceModel.UserName,
                Password = userServiceModel.Password,
                Email = userServiceModel.Email,
                Phone = userServiceModel.Phone,
                IsActive = userServiceModel.IsActive,
            };
            return user;
        }

        public UserServiceModel ValidateUser(string username, string password)
        {
            User loggedUser=_userRepo.ValidateUser(username, password);
            if(loggedUser != null)
            {
                return ConvertUserToUserServiceModel(loggedUser);
            }
            else
            {
                return null;
            }
        }

        public bool Register(string fname, string lname, string username, string password, string email, string phoneNumber)
        {
            User newUser = new User
            {
                FirstName = fname,
                LastName = lname,
                UserName = username,
                Password = password,
                Email = email,
                Phone = phoneNumber
            };
            int? record = _userRepo.RegisterUser(newUser);
            return record > 0 ? true : false;
        }

        public bool UpdateUser(UserServiceModel user, string name, string email, string phone)
        {
            User u  = ConvertUserServiceModelToUser(user);
            int record =_userRepo.UpdateUser(u, name, email, phone);
            return record > 0 ? true : false;
        }

        public List<UserServiceModel> GetAllUsers(UserServiceModel loggedUser)
        {
            User u = ConvertUserServiceModelToUser(loggedUser);
            if(u != null)
            {
                List<UserServiceModel> users = new List<UserServiceModel>();
                List<User> users2 = _userRepo.GetAllUsers(u);
                foreach (User item in users2)
                {
                    //if(item.Id != loggedUser.Id)
                    users.Add(ConvertUserToUserServiceModel(item));
                }
                return users;
            }
            else{
                return null;
            }
            
        }

        public UserServiceModel GetUserByName(string username)
        {
            return ConvertUserToUserServiceModel(_userRepo.GetUserByName(username));
        }

        public bool RequestConnection(UserServiceModel loggedUser, UserServiceModel requestedUser)
        {
            Connection conn = new Connection
            {
                UserSendId = loggedUser.Id,
                UserAcceptId = requestedUser.Id,
                ConnectionStatus = 0,
                ConnectionDate = DateTime.Now,
            };
            int? record = _userRepo.RequestConnection(conn);
            return record > 0 ? true : false;
        }

        public List<UserServiceModel> GetAllPendingUsers(UserServiceModel loggedUser)
        {
            User u = ConvertUserServiceModelToUser(loggedUser);
            List<User> users = _userRepo.GetAllPendingUsers(u);
            List<UserServiceModel> pendingUsers = new List<UserServiceModel>();
            foreach (User item in users)
            {
                pendingUsers.Add(ConvertUserToUserServiceModel(item));
            }
            return pendingUsers;
        }
        public bool AcceptUser(UserServiceModel loggedUser, UserServiceModel requestedUser)
        {
            User logUser = ConvertUserServiceModelToUser(loggedUser);
            User reqUser = ConvertUserServiceModelToUser(requestedUser);
            Connection conn = new Connection
            {
                UserSendId = loggedUser.Id,
                UserAcceptId = requestedUser.Id,
                ConnectionStatus = 1,
                ConnectionDate = DateTime.Now,
            };
            int record = _userRepo.AcceptUser(logUser, reqUser, conn);
            return record > 0 ? true : false;
        }
        public bool RejectUser(UserServiceModel loggedUser, UserServiceModel requestedUser)
        {
            User logUser = ConvertUserServiceModelToUser(loggedUser);
            User reqUser = ConvertUserServiceModelToUser(requestedUser);
            int record = _userRepo.RejectUser(logUser, reqUser);
            return record > 0 ? true : false;
        }
        public List<UserServiceModel> GetConnectedUsers(UserServiceModel loggedUser)
        {
            User logUser = ConvertUserServiceModelToUser(loggedUser);
            List<UserServiceModel> users = new List<UserServiceModel>();
            List<User> users1 = _userRepo.GetConnectedUsers(logUser);
            foreach (User item in users1)
            {
                users.Add(ConvertUserToUserServiceModel(item));
            }
            return users;
        }
    }
}
