﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using CybageConnect.Services.ServiceModels;
using CybageConnect.Services.Services.Iservices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services.Services
{
    public class KnowledgeSharingService : IKnowledgeSharingService
    {
        private readonly IKnowledgeSharingRepository _userRepo;
        public KnowledgeSharingService(IKnowledgeSharingRepository userRepo)
        {
            _userRepo = userRepo;
        }

        private BlogServiceModel ConvertBlogToBlogServiceModel(Blog blog)
        {
            BlogServiceModel blogServiceModel = new BlogServiceModel()
            {
                Id = blog.Id,
                BlogName = blog.BlogName,
                BlogContent = blog.BlogContent,
                BlogDate = blog.BlogDate,
                UserId = blog.UserId,
            };
            return blogServiceModel;
        }

        private Blog ConvertBlogServiceModelToBlog(BlogServiceModel blogServiceModel)
        {
            Blog blog = new Blog()
            {
                Id = blogServiceModel.Id,
                BlogName = blogServiceModel.BlogName,
                BlogContent = blogServiceModel.BlogContent,
                BlogDate = blogServiceModel.BlogDate,
                UserId = blogServiceModel.UserId,
            };
            return blog;
        }

        private ArticleServiceModel ConvertArticleToArticleServiceModel(Article article)
        {
            ArticleServiceModel articleServiceModel = new ArticleServiceModel()
            {
                Id = article.Id,
                ArticleName = article.ArticleName,
                ArticleContent = article.ArticleContent,
                ArticleDate = article.ArticleDate,
                UserId = article.UserId,
            };
            return articleServiceModel;
        }

        private Article ConvertArticleServiceModelToArticle(ArticleServiceModel articleServiceModel)
        {
            Article article = new Article()
            {
                Id = articleServiceModel.Id,
                ArticleName = articleServiceModel.ArticleName,
                ArticleContent = articleServiceModel.ArticleContent,
                ArticleDate = articleServiceModel.ArticleDate,
                UserId = articleServiceModel.UserId,
            };
            return article;
        }


        private ProjectInsightServiceModel ConvertProjectInsightToProjectInsightServiceModel(ProjectInsight projectInsight)
        {
            ProjectInsightServiceModel projectInsightServiceModel = new ProjectInsightServiceModel()
            {
                Id= projectInsight.Id,
                ProjectName = projectInsight.ProjectName,
                ProjectInsight1 = projectInsight.ProjectInsight1,
                InsightDate = projectInsight.InsightDate,
                UserId= projectInsight.UserId,
            };
            return projectInsightServiceModel;
        }

        private ProjectInsight ConvertProjectInsightServiceModelToProjectInsight(ProjectInsightServiceModel projectInsightServiceModel)
        {
            ProjectInsight projectInsight = new ProjectInsight()
            {
                Id=projectInsightServiceModel.Id,
                ProjectName=projectInsightServiceModel.ProjectName,
                ProjectInsight1=projectInsightServiceModel.ProjectInsight1,
                InsightDate=projectInsightServiceModel.InsightDate, 
                UserId= projectInsightServiceModel.UserId,
            };
            return projectInsight;
        }
        public bool AddBlogs(string? blogname, string? blogcontent, DateTime? blogdate, UserServiceModel loggedUser)
        {
            Blog newBLog = new Blog
            {
                BlogName = blogname,
                BlogContent = blogcontent,
                BlogDate = DateTime.Now,
                UserId = loggedUser.Id,
            };
            int record = _userRepo.AddBlogs(newBLog);
            return record > 0 ? true : false;
        }

        public List<BlogServiceModel> GetBlogs()
        {
            List<Blog> blogs = _userRepo.GetBlogs();
            List<BlogServiceModel> blogservicemodel = new List<BlogServiceModel>();
            foreach (Blog blog in blogs) 
            {
                blogservicemodel.Add(ConvertBlogToBlogServiceModel(blog));
            }
            return blogservicemodel;
        }

        public bool AddArticles(string? articlename, string? articlecontent, DateTime? articledate, UserServiceModel loggedUser)
        {
            Article newArticle = new Article
            {
                ArticleName = articlename,
                ArticleContent = articlecontent,
                ArticleDate = DateTime.Now,
                UserId = loggedUser.Id
            };
            int record = _userRepo.AddArticles(newArticle);
            return record > 0 ? true : false;
        }
        public List<ArticleServiceModel> GetArticles()
        {
            List<Article> articles = _userRepo.GetArticles();
            List<ArticleServiceModel> articleservicemodel = new List<ArticleServiceModel>();
            foreach (Article article in articles)
            {
                articleservicemodel.Add(ConvertArticleToArticleServiceModel(article));
            }
            return articleservicemodel;
        }

        public bool AddProjectInsights(string? projectname, string? projectinsight1, DateTime? insightdate, UserServiceModel loggedUser)
        {
            ProjectInsight newInsight = new ProjectInsight
            {
                ProjectName = projectname,
                ProjectInsight1 = projectinsight1,
                InsightDate = DateTime.Now,
                UserId = loggedUser.Id

            };
            int record = _userRepo.AddProjectInsights(newInsight);
            return record > 0 ? true : false;
        }

        public List<ProjectInsightServiceModel> GetProjectInsights()
        {
            List<ProjectInsight> insights = _userRepo.GetProjectInsights();
            List<ProjectInsightServiceModel> insightservicemodel = new List<ProjectInsightServiceModel>();
            foreach (ProjectInsight insight in insights)
            {
                insightservicemodel.Add(ConvertProjectInsightToProjectInsightServiceModel(insight));
            }
            return insightservicemodel;
        }
    }
}

