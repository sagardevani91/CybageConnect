﻿using CybageConnect.Entity.DB;
using CybageConnect.Services;
using Microsoft.EntityFrameworkCore.Design.Internal;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class ProfileMenu
    {
        public static void ShowProfileMenu()
        {
            Console.WriteLine("1.Show");
            Console.WriteLine("2.Edit");
            Console.WriteLine("3.Back to Main Menu");
            int option = Convert.ToInt32(Console.ReadLine());
            if(option == 1) 
            {
                //logic for showing the details
            }
            else if(option == 2)
            {
                Console.WriteLine("Enter below information for edit :");
                Console.WriteLine("Enter new name");
                string name = Console.ReadLine();
                Console.WriteLine("Enter new email");
                string email = Console.ReadLine();
                Console.WriteLine("Enter new phone");
                string phone = Console.ReadLine();


            }
            else if (option == 3)
            {
                UserMenu.ShowUserMenu();
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
