﻿using Azure.Identity;
using CybageConnect.Entity.DB;
using CybageConnect.Services;
using Microsoft.EntityFrameworkCore.Design.Internal;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class ProfileMenu
    {
        private static IKnowledgeSharingService _knowledgeSharingService;
        public ProfileMenu(KnowledgeSharingService knowledgeSharingService)
        {
            _knowledgeSharingService = knowledgeSharingService;
        }
        public static void ShowProfileMenu(User loggedUser, IUserService _userService)
        {
            Console.WriteLine("1.Show");
            Console.WriteLine("2.Edit");
            Console.WriteLine("3.Back to Main Menu");
            int option = Convert.ToInt32(Console.ReadLine());
            switch (option)
            {
                case 1:
                    Console.WriteLine("This is Your Pofile");
                    Console.WriteLine($"{loggedUser.Id} {loggedUser.UserName}");
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                    ShowProfileMenu(loggedUser, _userService);
                    break;
                case 2:
                    Console.WriteLine("Enter below information for edit :");
                    Console.WriteLine("Enter new name");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter new email");
                    string email = Console.ReadLine();
                    Console.WriteLine("Enter new phone");
                    string phone = Console.ReadLine();

                    string pattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";
                    bool isValid = true;

                    if (string.IsNullOrEmpty(name))
                    {
                        AuthenticationMenu.ErrorMessage("Name can't be Empty");
                        isValid = false;
                    }
                    if (!Regex.IsMatch(email, pattern))
                    {
                        AuthenticationMenu.ErrorMessage("Enter valid email");
                        isValid = false;
                    }
                    if (string.IsNullOrEmpty(phone))
                    {
                        AuthenticationMenu.ErrorMessage("Phone Number can't be empty");
                        isValid = false;
                    }
                    if (isValid)
                    {

                        _userService.UpdateUser(loggedUser, name, email, phone);
                        Console.WriteLine("Successfully Updated\n");
                        ShowProfileMenu(loggedUser, _userService);
                    }
                    else
                    {
                        ShowProfileMenu(loggedUser,_userService);
                    }
                    break;
                case 3:
                    UserMenu.ShowUserMenu(loggedUser, _userService,_knowledgeSharingService);
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                break;
            }
        }
        
    }
}
