﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using CybageConnect.Entity.Repository;
using CybageConnect.Services;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace CybageConnect.UI
{
    public class AuthenticationMenu
    {
        public static void ErrorMessage(string msg)
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(msg);
            Console.ResetColor();

        }
        static string ReadPassword()
        {
            var pass = string.Empty;
            ConsoleKey key;
            do
            {
                var keyInfo = Console.ReadKey(intercept: true);
                key = keyInfo.Key;

                // remove last character from password
                if (key == ConsoleKey.Backspace && pass.Length > 0)
                {
                    Console.Write("\b \b");
                    pass = pass[0..^1];
                }
                // on any key other than control characters add it to the password
                else if (!char.IsControl(keyInfo.KeyChar))
                {
                    Console.Write("*");
                    pass += keyInfo.KeyChar;
                }
            } while (key != ConsoleKey.Enter);
            Console.WriteLine();
            return pass;
        }


        public static void Login(IUserService userService)
        {
            Console.WriteLine("\n============ LogIn =============");
            Console.Write("Enter your username: ");
            string username = Console.ReadLine();
            Console.Write("Enter your password: ");
            string? password = ReadPassword();
            Console.WriteLine("1. Login\n2. Back to Main Menu");
            int option = Convert.ToInt32(Console.ReadLine());
            if (option == 1)
            {
                // check if user id or password is empty
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    ErrorMessage("User Name or Password can't be empty");
                }
                else
                {
                    bool isLoggedIn = userService.ValidateUser(username, password);
                    if (isLoggedIn)
                    {
                        UserMenu.ShowUserMenu();
                    }
                    else
                    {
                        Console.WriteLine("Invalid Username or password");
                    }
                }  
            }
            else if (option == 2)
            {
                return;
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }

        public static void Register(IUserService userService)
        {
            Console.WriteLine("Please enter the following details to register:");
            Console.Write("Name: ");
            string name = Console.ReadLine();
            Console.Write("Username: ");
            string username = Console.ReadLine();
            Console.Write("Password: ");
            string password = Console.ReadLine();
            Console.Write("Email Address: ");
            string email = Console.ReadLine();
            Console.Write("Phone Number: ");
            string phoneNumber = Console.ReadLine();

            Console.WriteLine("1. Register\n2. Back to Main Menu");
            int option = Convert.ToInt32(Console.ReadLine());

            if (option == 1)
            {
                // for email validation
                string pattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";
                bool isValid = true;

                if (string.IsNullOrEmpty(name))
                {
                    ErrorMessage("Name can't be Empty");
                    isValid = false;
                }
                if (string.IsNullOrEmpty(username))
                {
                    ErrorMessage("User Name can't be empty");
                    isValid = false;
                }
                if (string.IsNullOrEmpty(password))
                {
                    ErrorMessage("Password can't be empty");
                    isValid = false;
                }
                if(!Regex.IsMatch(email, pattern))
                {
                    ErrorMessage("Enter valid email");
                    isValid = false;
                }
                if (string.IsNullOrEmpty(phoneNumber)) 
                {
                    ErrorMessage("Phone Number can't be empty");
                    isValid = false;
                }
                if(isValid) 
                {
                    userService.Register(name, username, password, email, phoneNumber);
                }
                else
                {
                    Register(userService);
                }
            }
            else if (option == 2)
            {
                return;
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }         
        }
    }
}
