﻿//using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using CybageConnect.Entity.Repository;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.ComponentModel.Design;
using CybageConnect.Services.Services.Iservices;
using CybageConnect.Services.ServiceModels;

namespace CybageConnect.UI
{
    public class AuthenticationMenu
    {
        public static void ErrorMessage(string msg)
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(msg);
            Console.ResetColor();
        }
        static string ReadPassword()
        {
            var pass = string.Empty;
            ConsoleKey key;
            do
            {
                var keyInfo = Console.ReadKey(intercept: true);
                key = keyInfo.Key;

                // remove last character from password
                if (key == ConsoleKey.Backspace && pass.Length > 0)
                {
                    Console.Write("\b \b");
                    pass = pass[0..^1];
                }
                // on any key other than control characters add it to the password
                else if (!char.IsControl(keyInfo.KeyChar))
                {
                    Console.Write("*");
                    pass += keyInfo.KeyChar;
                }
            } while (key != ConsoleKey.Enter);
            Console.WriteLine();
            return pass;
        }


        public static void Login(IUserService _userService, IKnowledgeSharingService _knowledgeSharingService)
        {
            try
            {
                Console.Clear();
                Console.WriteLine("\n══════════ LogIn ══════════");
                Console.Write("Enter your username: ");
                string username = Console.ReadLine();
                Console.Write("Enter your password: ");
                string? password = ReadPassword();
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    ErrorMessage("User Name or Password can't be empty");
                }
                else
                {

                    UserServiceModel loggedUser = _userService.ValidateUser(username, password);
                    if (loggedUser != null)
                    {
                        UserMenu.ShowUserMenu(loggedUser, _userService, _knowledgeSharingService);
                    }
                    else
                    {
                        Console.WriteLine("Invalid Username or password");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        public static void Register(IUserService _userService)
        {
            try
            {
                Console.Clear();
                Console.WriteLine("Please enter the following details to register:");
                Console.Write("Enter First Name: ");
                string? fname = Console.ReadLine();
                Console.Write("Enter Last Name: ");
                string? lname = Console.ReadLine();
                Console.Write("Username: ");
                string? username = Console.ReadLine();
                Console.Write("Password: ");
                string? password = Console.ReadLine();
                Console.Write("Email Address: ");
                string? email = Console.ReadLine();
                Console.Write("Phone Number: ");
                string? phoneNumber = Console.ReadLine();

                string patternEmail = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";
                string patternPhone = @"^\d{10}$";

                bool isValid = true;

                if (string.IsNullOrEmpty(fname))
                {
                    ErrorMessage("Name can't be Empty");
                    isValid = false;
                }
                if (string.IsNullOrEmpty(username))
                {
                    ErrorMessage("User Name can't be empty");
                    isValid = false;
                }
                if (string.IsNullOrEmpty(password))
                {
                    ErrorMessage("Password can't be empty");
                    isValid = false;
                }
                if (!Regex.IsMatch(email, patternEmail))
                {
                    ErrorMessage("Enter valid email");
                    isValid = false;
                }
                if (!Regex.IsMatch(phoneNumber, patternPhone))
                {
                    ErrorMessage("Enter Valid Phone number");
                    isValid = false;
                }
                if (isValid)
                {
                    bool isRegistered = _userService.Register(fname, lname, username, password, email, phoneNumber);
                    if (isRegistered)
                    {
                        Console.WriteLine("Registration SuccessFul");
                    }
                }
                else
                {
                    Console.Write("Press any key to continue.");
                    Console.ReadKey();
                    Register(_userService);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
