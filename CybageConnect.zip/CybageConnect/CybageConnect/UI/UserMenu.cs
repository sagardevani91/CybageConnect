﻿using CybageConnect.Entity.DB;
using CybageConnect.Services.ServiceModels;
using CybageConnect.Services.Services.Iservices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class UserMenu
    {
        public static void ShowUserMenu(UserServiceModel loggedUser, IUserService _userService,IKnowledgeSharingService _knowledgeSharingService)
        {
            Console.Clear();
            Console.WriteLine("╔═════════ User Menu ══════════╗");
            Console.WriteLine("║1. Profile                    ║");
            Console.WriteLine("║2. Connect                    ║");
            Console.WriteLine("║3. Share                      ║");
            Console.WriteLine("║4.Log Out                     ║");
            Console.WriteLine("╚══════════════════════════════╝");
            Console.Write("Please select an option: ");
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid Input, Please Enter Valid option");
                Console.ResetColor();
            }
            switch(choice)
            {
                case 1:
                    ProfileMenu.ShowProfileMenu(loggedUser,_userService);
                    break;
                case 2:
                    Console.WriteLine("Network");
                    NetworkMenu.ShowNetworkMenu(loggedUser,_userService);
                    break;
                case 3:
                    Console.WriteLine("Share");
                    ShareMenu.ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                    break;
                case 4:
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    ShowUserMenu(loggedUser,_userService, _knowledgeSharingService);
                    break;
            }
        }
    }
}
