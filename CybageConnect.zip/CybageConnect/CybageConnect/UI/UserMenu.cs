﻿using CybageConnect.Entity.DB;
using CybageConnect.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class UserMenu
    {
        
        public static void ShowUserMenu(User loggedUser, IUserService _userService,IKnowledgeSharingService _knowledgeSharingService)
        {
            Console.WriteLine("\n==============Menu==================\n");
            Console.WriteLine("1.Profile");
            Console.WriteLine("2.Networking");
            Console.WriteLine("3.Sharing");
            Console.WriteLine("4.Log Out");
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid Input, Please Try again");
                Console.ResetColor();
            }
            switch(choice)
            {
                case 1:
                    Console.WriteLine("Profile");
                    ProfileMenu.ShowProfileMenu(loggedUser,_userService);
                    break;
                case 2:
                    Console.WriteLine("Network");
                    NetworkMenu.ShowNetworkMenu(loggedUser,_userService);
                    break;
                case 3:
                    Console.WriteLine("Share");
                    ShareMenu.ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        }
    }
}
