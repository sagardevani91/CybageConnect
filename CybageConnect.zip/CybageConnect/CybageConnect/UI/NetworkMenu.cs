﻿using CybageConnect.Entity.DB;
using CybageConnect.Services.ServiceModels;
using CybageConnect.Services.Services;
using CybageConnect.Services.Services.Iservices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class NetworkMenu
    {
        private static IKnowledgeSharingService _knowledgeSharingService;
        public NetworkMenu(KnowledgeSharingService knowledgeSharingService)
        {
            _knowledgeSharingService = knowledgeSharingService;
        }
        public static void ShowNetworkMenu(UserServiceModel loggedUser, IUserService _userService)
        {
            Console.Clear();
            Console.WriteLine("╔═════════ Network Menu ══════════╗");
            Console.WriteLine("║1.Pending Request                ║");
            Console.WriteLine("║2.Connect with Others            ║");
            Console.WriteLine("║3.My Connnection                 ║");
            Console.WriteLine("║4.Back to Main Menu              ║");
            Console.WriteLine("╚═════════════════════════════════╝");
            Console.Write("Please select an option: ");
            int option;
            while (!int.TryParse(Console.ReadLine(), out option))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid Input, Please Enter Valid option");
                Console.ResetColor();
            }
            switch (option)
            {
                case 1:
                    try
                    {
                        List<UserServiceModel> pendingUsers = _userService.GetAllPendingUsers(loggedUser);
                        if (pendingUsers.Count == 0)
                        {
                            Console.WriteLine("Thre are no any pending Requests.");
                            Console.Write("Press any key to continue.");
                            Console.ReadKey();
                            ShowNetworkMenu(loggedUser, _userService);
                        }
                        foreach (var item in pendingUsers)
                        {
                            Console.WriteLine($"User Name : {item.UserName} ║ Name : {item.FirstName + item.LastName} ║ Email : {item.Email} ║ Phone : {item.Phone}");
                        }
                        Console.WriteLine("Enter UserName you want to accept or reject Request");
                        string? pendingUser = Console.ReadLine();
                        UserServiceModel user1 = _userService.GetUserByName(pendingUser);
                        if (user1 != null)
                        {
                            Console.WriteLine("1.Accept\n2.Reject");
                            int choice;
                            while (!int.TryParse(Console.ReadLine(), out choice))
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Invalid Input, Please Enter Valid option");
                                Console.ResetColor();
                            }
                            switch (choice)
                            {
                                case 1:
                                    bool isAccepted = _userService.AcceptUser(loggedUser, user1);
                                    if (isAccepted)
                                    {
                                        Console.WriteLine("Request Accepted");
                                        Console.Write("Press any key to continue.");
                                        Console.ReadKey();
                                        ShowNetworkMenu(loggedUser, _userService);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Something went wrong");
                                    }
                                    break;
                                case 2:
                                    bool isRejected = _userService.RejectUser(loggedUser, user1);
                                    if (isRejected)
                                    {
                                        Console.WriteLine("Request Rejected");
                                        Console.Write("Press any key to continue.");
                                        Console.ReadKey();
                                        ShowNetworkMenu(loggedUser, _userService);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Something went wrong");
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Enter valid UserName");
                            Console.Write("Press any key to continue.");
                            Console.ReadKey();
                            ShowNetworkMenu(loggedUser, _userService);
                        }
                    }catch(Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    
                    break;
                case 2:
                    try
                    {
                        List<UserServiceModel> users= _userService.GetAllUsers(loggedUser);
                        if (users.Count == 0 || users!=null)
                        {
                            Console.WriteLine("There are no user for connection");
                            Console.Write("Press any key to continue.");
                            Console.ReadKey();
                            ShowNetworkMenu(loggedUser, _userService);
                        }
                        else
                        {
                            foreach (UserServiceModel item in users)
                            {
                                if (item != loggedUser)
                                {
                                    Console.WriteLine($"User Name : {item.UserName} ║ Name : {item.FirstName + item.LastName} ║ Email : {item.Email} ║ Phone : {item.Phone}");
                                }
                            }
                            Console.WriteLine("Enter Username you want to connect with :");
                            string? username = Console.ReadLine();
                            UserServiceModel user = _userService.GetUserByName(username);
                            bool isConnecting = _userService.RequestConnection(loggedUser, user);
                            if (isConnecting)
                            {
                                Console.WriteLine("Connection Request has been sent");
                                Console.Write("Press any key to continue.");
                                Console.ReadKey();
                                ShowNetworkMenu(loggedUser, _userService);
                            }
                            else
                            {
                                Console.WriteLine("Enter valid UserName");
                                Console.Write("Press any key to continue.");
                                Console.ReadKey();
                                ShowNetworkMenu(loggedUser, _userService);
                            }
                        }
                    }catch(Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 3:
                    try
                    {
                        List<UserServiceModel> connectedUsers = _userService.GetConnectedUsers(loggedUser);
                        if (connectedUsers.Count == 0)
                        {
                            Console.WriteLine("You have not connetion with anyone");
                            Console.Write("Press any key to continue.");
                            Console.ReadKey();
                            ShowNetworkMenu(loggedUser, _userService);
                        }
                        foreach (var item in connectedUsers)
                        {
                            if(item.Id != loggedUser.Id)
                            {
                                Console.WriteLine($"User Name : {item.UserName} ║ Name : {item.FirstName + item.LastName} ║ Email : {item.Email} ║ Phone : {item.Phone}");
                            }
                        }
                        Console.Write("Press any key to continue.");
                        Console.ReadKey();
                        ShowNetworkMenu(loggedUser, _userService);
                    }catch(Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 4:
                    UserMenu.ShowUserMenu(loggedUser, _userService, _knowledgeSharingService);
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;
            }
        }
    }
}
