﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class NetworkMenu
    {
        public static void ShowNetworkMenu()
        {
            Console.WriteLine("1.Pending Request");
            Console.WriteLine("2.Connect with Others");
            Console.WriteLine("3.Back to Main Menu");
            int option = Convert.ToInt32(Console.ReadLine());
            if (option == 1)
            {
                //logic for showing pending requests
            }
            else if (option == 2)
            {
                //logic for connecting with others
            }
            else if (option == 3)
            {
                UserMenu.ShowUserMenu();
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
