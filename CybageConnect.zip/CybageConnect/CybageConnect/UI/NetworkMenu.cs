﻿using CybageConnect.Entity.DB;
using CybageConnect.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class NetworkMenu
    {
        private static IKnowledgeSharingService _knowledgeSharingService;
        public NetworkMenu(KnowledgeSharingService knowledgeSharingService)
        {
            _knowledgeSharingService = knowledgeSharingService;
        }
        public static void ShowNetworkMenu(User loggedUser, IUserService _userService)
        {
            
            Console.WriteLine("1.Pending Request");
            Console.WriteLine("2.Connect with Others");
            Console.WriteLine("3.My Connnection");
            Console.WriteLine("4.Back to Main Menu");
            int option = Convert.ToInt32(Console.ReadLine());
            switch (option)
            {
                case 1:
                    List<User> pendingUsers = new List<User>();
                    pendingUsers = _userService.GetAllPendingUsers(loggedUser);
                    if (pendingUsers.Count == 0)
                    {
                        Console.WriteLine("Thre are no Users");
                        ShowNetworkMenu(loggedUser, _userService);
                    }
                    foreach (var item in pendingUsers)
                    {
                        Console.WriteLine($"{item.UserName} {item.Email}");
                    }
                    Console.WriteLine("Enter User name you want to accept or reject Request");
                    string? pendingUser = Console.ReadLine();
                    User user1 = _userService.GetUserByName(pendingUser);
                    if(user1 != null)
                    {
                        Console.WriteLine("1.Accept\n2.Reject");
                        int choice = Convert.ToInt32(Console.ReadLine());
                        switch(choice)
                        {
                            case 1:
                                _userService.AcceptUser(loggedUser, user1);
                                break;
                            case 2:
                                _userService.RejectUser(loggedUser, user1);
                                break;
                            default:
                                break;
                        }
                    }
                    break;
                case 2:
                    List<User> users = new List<User>();
                    users = _userService.GetAllUsers(loggedUser);
                    if(users.Count == 0)
                    {
                        Console.WriteLine("Thre are no Users");
                        ShowNetworkMenu(loggedUser, _userService);
                    }
                    foreach (User item in users)
                    {
                        if (item != loggedUser)
                        {
                            Console.WriteLine($"{item.Id} | {item.FirstName} | {item.UserName} | {item.Email}");
                        }
                    }
                    Console.WriteLine("Enter Username you want to connect with :");
                    string? username = Console.ReadLine();
                    User user = _userService.GetUserByName(username);
                    bool isConnecting = _userService.RequestConnection(loggedUser, user);
                    if (isConnecting)
                    {
                        Console.WriteLine("Connection Request has been sent");
                    }
                    else
                    {
                        Console.WriteLine("Something went wrong");
                    }
                    break;
                case 3:
                    List<User> connectedUsers = _userService.GetConnectedUsers(loggedUser);
                    if (connectedUsers.Count == 0)
                    {
                        Console.WriteLine("Thre are no Users");
                        ShowNetworkMenu(loggedUser, _userService);
                    }
                    foreach (var item in connectedUsers)
                    {
                        Console.WriteLine($"{item.Id} | {item.FirstName} | {item.UserName} | {item.Email}");
                    }
                    break;
                case 4:
                    UserMenu.ShowUserMenu(loggedUser, _userService, _knowledgeSharingService);
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;
            }
        }
    }
}
