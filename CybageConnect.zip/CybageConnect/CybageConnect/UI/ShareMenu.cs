﻿using CybageConnect.Entity.DB;
using CybageConnect.Services.ServiceModels;
using CybageConnect.Services.Services.Iservices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class ShareMenu
    { 
        public static void ShowShareMenu(UserServiceModel loggedUser, IUserService _userService,IKnowledgeSharingService _knowledgeSharingService)
        {
            Console.Clear();
            Console.WriteLine("╔═════════ Share Menu ═════════╗");
            Console.WriteLine("║1. Blog                       ║");
            Console.WriteLine("║2. Article                    ║");
            Console.WriteLine("║3. Project Insights           ║");
            Console.WriteLine("║4. Back to Main Menu          ║");
            Console.WriteLine("╚══════════════════════════════╝");
            Console.Write("Please select an option: ");
            int option;
            while (!int.TryParse(Console.ReadLine(), out option))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid Input, Please Enter Valid option");
                Console.ResetColor();
            }
            switch (option)
            {
                case 1:
                    Console.WriteLine("Welcome to Blog Page!");
                    Console.WriteLine("1. Add");
                    Console.WriteLine("2. Show");
                    Console.Write("Please select an option: ");
                    int choice;
                    while (!int.TryParse(Console.ReadLine(), out choice))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid Input, Please Enter Valid option");
                        Console.ResetColor();
                    }
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Please enter the following details to add a blog:");

                            Console.Write("BlogName: ");
                            string blogname = Console.ReadLine();
                            Console.Write("Blogcontent: ");
                            string blogcontent = Console.ReadLine();
                            DateTime datetime = DateTime.Now;
                            bool isValid = true;

                            if (string.IsNullOrEmpty(blogname))
                            {
                                AuthenticationMenu.ErrorMessage("Please enter the blog name ");
                                isValid = false;
                            }

                            if (string.IsNullOrEmpty(blogcontent))
                            {
                                AuthenticationMenu.ErrorMessage("Please enter the blog content ");
                                isValid = false;
                            }

                            if (isValid)
                            {
                                try
                                {
                                    bool isBlogAdded= _knowledgeSharingService.AddBlogs(blogname, blogcontent, datetime, loggedUser);
                                    if (isBlogAdded)
                                    {
                                        Console.WriteLine("Blog Added Successfully");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Something went wrong");
                                    }
                                    Console.Write("Press any key to continue.");
                                    Console.ReadKey();
                                    ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                                }catch (Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                            }
                            else
                            {
                                ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                            }
                            break;
                        case 2:
                            {
                                try
                                {
                                    List<BlogServiceModel> blogs = _knowledgeSharingService.GetBlogs();
                                    Console.WriteLine("\n=========== BLOGS =============");
                                    foreach (var item in blogs)
                                    {
                                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                                        Console.WriteLine("Blog Name: " + item.BlogName + ", " + "Blog Content: " + item.BlogContent);
                                        Console.ResetColor();
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                                    Console.Write("Press any key to continue.");
                                    Console.ReadKey();
                                    ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                            }
                            break;
                        default:
                            ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                            break;
                    }
                    break;
                case 2:
                    Console.WriteLine("Welcome to Article Page!");
                    Console.WriteLine("1. Add");
                    Console.WriteLine("2. Show");
                    Console.Write("Please select an option: ");
                    while (!int.TryParse(Console.ReadLine(), out choice))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid Input, Please Enter Valid option");
                        Console.ResetColor();
                    }
                    switch (choice)
                    {
                        case 1:
                            try
                            {
                                {
                                    Console.WriteLine("Please enter the following details to add an article:");

                                    Console.Write("Article Name: ");
                                    string articlename = Console.ReadLine();
                                    Console.Write("Article content: ");
                                    string articlecontent = Console.ReadLine();
                                    DateTime datetime = DateTime.Now;
                                    bool isValid = true;

                                    if (string.IsNullOrEmpty(articlename))
                                    {
                                        AuthenticationMenu.ErrorMessage("Please enter the article name ");
                                        isValid = false;
                                    }

                                    if (string.IsNullOrEmpty(articlecontent))
                                    {
                                        AuthenticationMenu.ErrorMessage("Please enter the article content ");
                                        isValid = false;
                                    }

                                    if (isValid)
                                    {

                                        bool isArticleAdded = _knowledgeSharingService.AddArticles(articlename, articlecontent, datetime, loggedUser);
                                        if (isArticleAdded)
                                        {
                                            Console.WriteLine("Artical Added Successfully");
                                        }
                                        else
                                        {
                                            Console.WriteLine("Something went wrong");
                                        }
                                        Console.Write("Press any key to continue.");
                                        Console.ReadKey();
                                        ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                                    }
                                    else
                                    {
                                        ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                                    }
                                }
                            }
                            catch(Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            break;
                        case 2:
                            
                                try
                                {
                                    List<ArticleServiceModel> articles = _knowledgeSharingService.GetArticles();
                                    Console.WriteLine("\n=========== ARTICLES =============");
                                    foreach (var item in articles)
                                    {
                                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                                        Console.WriteLine("Article Name: " + item.ArticleName + ", " + "Article Content: " + item.ArticleContent);
                                        Console.ResetColor();
                                    }
                               
                                Console.Write("Press any key to continue.");
                                Console.ReadKey();
                                ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                            
                            break;
                        default:
                            ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                            break;
                    }
                    break;
                case 3:
                    Console.WriteLine("Welcome to Project Insight Page!");
                    Console.WriteLine("1. Add");
                    Console.WriteLine("2. Show");
                    Console.Write("Please select an option: ");
                    while (!int.TryParse(Console.ReadLine(), out choice))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid Input, Please Enter Valid option");
                        Console.ResetColor();
                    }

                    switch (choice)
                    {
                        case 1:
                            {
                                Console.WriteLine("Please enter the following details to add a Project Insight:");

                                Console.Write("Insight Name: ");
                                string insightname = Console.ReadLine();
                                Console.Write("Insight content: ");
                                string insightcontent = Console.ReadLine();
                                DateTime datetime = DateTime.Now;
                                bool isValid = true;

                                if (string.IsNullOrEmpty(insightname))
                                {
                                    AuthenticationMenu.ErrorMessage("Please enter the project insight name ");
                                    isValid = false;
                                }

                                if (string.IsNullOrEmpty(insightcontent))
                                {
                                    AuthenticationMenu.ErrorMessage("Please enter the project insight content ");
                                    isValid = false;
                                }

                                if (isValid)
                                {
                                        bool isInsightAddes= _knowledgeSharingService.AddProjectInsights(insightname, insightcontent, datetime, loggedUser);
                                        if (isInsightAddes)
                                        {
                                            Console.WriteLine("Insight Added Successfully");
                                        }
                                        else
                                        {
                                            Console.WriteLine("Something went wrong");
                                        }
                                    Console.Write("Press any key to continue.");
                                    Console.ReadKey();
                                    ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                                }
                                else
                                {
                                    ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                                }
                            }
                            break;
                        case 2:
                            {
                                try
                                {
                                    List<ProjectInsightServiceModel> insights =  _knowledgeSharingService.GetProjectInsights();
                                    Console.WriteLine("\n=========== Project Insights =============");
                                    foreach (var item in insights)
                                    {
                                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                                        Console.WriteLine("Project Name: " + item.ProjectName + ", " + "Project Insight: " + item.ProjectInsight1);
                                        Console.ResetColor();
                                    }
                                }
                                catch(Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                                Console.Write("Press any key to continue.");
                                Console.ReadKey();
                                ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                            }
                            break;
                        default:
                            ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);
                            break;
                    }
                    break;
                case 4:
                    UserMenu.ShowUserMenu(loggedUser, _userService, _knowledgeSharingService);
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    ShowShareMenu(loggedUser, _userService, _knowledgeSharingService);

                    break;
            }
        }
    }
}
