﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class ShareMenu
    {
        public static void ShowShareMenu()
        {
            Console.WriteLine("1.Add Blog");
            Console.WriteLine("2.Add Artical");
            Console.WriteLine("3.Add Project Insights");
            Console.WriteLine("4.Back to Main Menu");
            int option = Convert.ToInt32(Console.ReadLine());
            if (option == 1)
            {
                //logic for adding blogs
            }
            else if (option == 2)
            {
                //logic for adding articals
            }
            else if(option == 3)
            {
                //logic for adding insights
            }
            else if (option == 4)
            {
                UserMenu.ShowUserMenu();
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
