﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository;
using CybageConnect.Entity.Repository.IRepository;
using CybageConnect.Services;
using Microsoft.Extensions.DependencyInjection;
using CybageConnect.UI;

namespace CybageConnect
{
    public class Program
    {
        //private readonly IUserService _userService;

        //public Program(IUserService userService)
        //{
        //    _userService = userService;
        //}
        static void Main(string[] args)
        {
            var serviceProvider = new ServiceCollection()
            .AddDbContext<CybageConnectContext>()
            .AddSingleton<IUserService, UserService>()
            .AddSingleton<IUserRepository, UserRepository>()
            .BuildServiceProvider();

            var userService = serviceProvider.GetService<IUserService>();

            while (true)
            {
                Console.WriteLine("Welcome to Cybage Connect!");
                Console.WriteLine("1. Login to your profile");
                Console.WriteLine("2. Register with Cybage Connect");
                Console.WriteLine("3. Exit");

                Console.Write("Please select an option: ");
                int choice;
                while (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid Input, Enter Valid Input");
                    Console.ResetColor();
                }
                switch (choice)
                {
                    case 1:
                        AuthenticationMenu.Login(userService);
                        break;
                    case 2:
                        AuthenticationMenu.Register(userService);
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
    }
}
