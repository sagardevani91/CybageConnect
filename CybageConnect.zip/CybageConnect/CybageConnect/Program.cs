﻿using CybageConnect.Entity.DB;
using CybageConnect.Services;
using Microsoft.Extensions.DependencyInjection;

namespace CybageConnect
{
    public class Program
    {
        static void Main(string[] args)
        {
            var serviceProvider = new ServiceCollection()
            .AddDbContext<CybageConnectContext>()
            .AddSingleton<IUserService, UserService>() 
            .BuildServiceProvider();

            var service = serviceProvider.GetService<IUserService>();

            while (true)
            {
                Console.WriteLine("Welcome to Cybage Connect!");
                Console.WriteLine("1. Login to your profile");
                Console.WriteLine("2. Register with Cybage Connect");
                Console.WriteLine("3. Exit");

                Console.Write("Please select an option: ");
                int choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        service.Login();
                        break;
                    case 2:
                        service.Register();
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
    }
}
