﻿using Azure.Identity;
using CybageConnect.Entity.DB;
using CybageConnect.Services;
using Microsoft.EntityFrameworkCore.Design.Internal;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CybageConnect.UI
{
    public class ProfileMenu
    {
        private static IKnowledgeSharingService _knowledgeSharingService;
        public ProfileMenu(KnowledgeSharingService knowledgeSharingService)
        {
            _knowledgeSharingService = knowledgeSharingService;
        }
        public static void ShowProfileMenu(User loggedUser, IUserService _userService)
        {
            Console.Clear();
            Console.WriteLine("╔═════════ User Menu ══════════╗");
            Console.WriteLine("║1. View Profile               ║");
            Console.WriteLine("║2. Edit Profile               ║");
            Console.WriteLine("║3. Back to Main MWnu          ║");
            Console.WriteLine("╚══════════════════════════════╝");
            int option;
            while (!int.TryParse(Console.ReadLine(), out option))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid Input, Please Enter Valid option");
                Console.ResetColor();
            }
            switch (option)
            {
                case 1:
                    Console.WriteLine("This is Your Pofile");
                    Console.WriteLine($"User Name : {loggedUser.UserName} ║ Name : {loggedUser.FirstName + loggedUser.LastName} ║ Email : {loggedUser.Email} ║ Phone : {loggedUser.Phone}");
                    Console.WriteLine("Press any key to continue..");
                    Console.ReadKey();
                    ShowProfileMenu(loggedUser, _userService);
                    break;
                case 2:
                    Console.WriteLine("Enter Below information for edit profile :");
                    Console.WriteLine("Enter your name");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter your email");
                    string email = Console.ReadLine();
                    Console.WriteLine("Enter your phone");
                    string phone = Console.ReadLine();

                    string patternEmail = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";
                    string patternPhone = @"^\d{10}$";
                    bool isValid = true;

                    if (string.IsNullOrEmpty(name))
                    {
                        AuthenticationMenu.ErrorMessage("Name can't be Empty");
                        isValid = false;
                    }
                    if (!Regex.IsMatch(email, patternEmail))
                    {
                        AuthenticationMenu.ErrorMessage("Enter valid email");
                        isValid = false;
                    }
                    if (!Regex.IsMatch(phone, patternPhone))
                    {
                        AuthenticationMenu.ErrorMessage("Enter valid Phone Number");
                        isValid = false;
                    }
                    if (isValid)
                    {
                        bool isUpdated = _userService.UpdateUser(loggedUser, name, email, phone);
                        if (isUpdated)
                        {
                            Console.WriteLine("Profile Successfully Updated\n");
                            Console.WriteLine($"User Name : {loggedUser.UserName} ║ Name : {loggedUser.FirstName + loggedUser.LastName} ║ Email : {loggedUser.Email} ║ Phone : {loggedUser.Phone}");
                            Console.Write("Press any key to continue.");
                            Console.ReadKey();
                            ShowProfileMenu(loggedUser, _userService);
                        }
                        else
                        {
                            Console.WriteLine("Something went wrong");
                        }
                    }
                    else
                    {
                        Console.Write("Press any key to continue.");
                        Console.ReadKey();
                        ShowProfileMenu(loggedUser,_userService);
                    }
                    break;
                case 3:
                    UserMenu.ShowUserMenu(loggedUser, _userService,_knowledgeSharingService);
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                break;
            }
        }
    }
}
