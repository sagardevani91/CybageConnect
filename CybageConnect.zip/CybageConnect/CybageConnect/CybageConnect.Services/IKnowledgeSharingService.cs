﻿using CybageConnect.Entity.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services
{
    public interface IKnowledgeSharingService
    {
        bool AddBlogs(string? blogname, string? blogcontent, DateTime? blogdate, User loggedUser);
        List<Blog> GetBlogs();

        bool AddArticles(string? articlename, string? articlecontent, DateTime? articledate, User loggedUser);

        List<Article> GetArticles();
        bool AddProjectInsights(string? projectname, string? projectinsight1, DateTime? insightdate, User loggedUser);

        List<ProjectInsight> GetProjectInsights();
    }
}
