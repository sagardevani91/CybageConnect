﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Services
{
    public class KnowledgeSharingService : IKnowledgeSharingService
    {
        private readonly IKnowledgeSharingRepository _userRepo;
        public KnowledgeSharingService(IKnowledgeSharingRepository userRepo)
        {
            _userRepo = userRepo;
        }
        public bool AddBlogs(string? blogname, string? blogcontent, DateTime? blogdate, User loggedUser)
        {
            Blog newBLog = new Blog
            {
                BlogName = blogname,
                BlogContent = blogcontent,
                BlogDate = DateTime.Now,
                UserId = loggedUser.Id,
            };
            int record =_userRepo.AddBlogs(newBLog);
            return (record > 0) ? true : false;
        }

        public List<Blog> GetBlogs()
        {
            return _userRepo.GetBlogs();
        }

        public bool AddArticles(string? articlename, string? articlecontent, DateTime? articledate, User loggedUser)
        {
            Article newArticle = new Article
            {
                ArticleName = articlename,
                ArticleContent = articlecontent,
                ArticleDate = DateTime.Now,
                UserId = loggedUser.Id
            };
            int record = _userRepo.AddArticles(newArticle);
            return (record > 0)?true:false;
        }
        public List<Article> GetArticles()
        {
            return _userRepo.GetArticles();
        }

        public bool AddProjectInsights(string? projectname, string? projectinsight1, DateTime? insightdate, User loggedUser)
        {
            ProjectInsight newInsight = new ProjectInsight
            {
                ProjectName = projectname,
                ProjectInsight1 = projectinsight1,
                InsightDate = DateTime.Now,
                UserId = loggedUser.Id

            };
            int record = _userRepo.AddProjectInsights(newInsight);
            return (record > 0) ? true : false;
        }

        public List<ProjectInsight> GetProjectInsights()
        {
            return _userRepo.GetProjectInsights();
        }
    }
}

