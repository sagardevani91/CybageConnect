﻿using CybageConnect.Entity.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Entity.Repository.IRepository
{
    public interface IUserRepository
    {
        User ValidateUser(string username, string password);
        int RegisterUser(User user);
        int UpdateUser(User user, string name, string email, string phone);
        List<User> GetAllUsers(User loggedUser);
        User GetUserByName(string username);
        int RequestConnection(Connection conn);
        List<User> GetAllPendingUsers(User loggedUser);
        int AcceptUser(User loggedUser,User user);
        int RejectUser(User loggedUser, User user);
        List<User> GetConnectedUsers(User loggedUser);
    }
}
