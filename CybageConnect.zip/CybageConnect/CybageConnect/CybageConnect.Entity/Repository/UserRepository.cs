﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Entity.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly CybageConnectContext _context;

        public UserRepository(CybageConnectContext context)
        {
            _context = context;
        }

        public User ValidateUser(string username, string password)
        {
            return _context.Users.FirstOrDefault(u => u.UserName == username && u.Password == password);

            //if (user != null)
            //{
            //    Console.WriteLine("Login successful! Welcome, " + user.FirstName + "!"); 
            //}
            //else
            //{
            //    Console.WriteLine("Invalid username or password. Please try again.");
            //}
        }
        public int RegisterUser(User user)
        {
            if (_context.Users.Any(u => u.UserName == user.UserName))
            {
                Console.WriteLine("Username already exists. Please choose a different one.");
                return 0;
            }

            if (_context.Users.Any(u => u.Email == user.Email))
            {
                Console.WriteLine("Email Address already exists. Please choose a different one.");
                return 0;
            }

            if (_context.Users.Any(u => u.Phone == user.Phone))
            {
                Console.WriteLine("Phone Number already exists. Please choose a different one.");
                return 0;
            }
            _context.Users.Add(user);
            return _context.SaveChanges();
        }

        public int UpdateUser(User user, string name, string email, string phone)
        {
            var existingUser = _context.Users.FirstOrDefault(u => u.Id == user.Id);

            if (existingUser != null)
            {
                existingUser.Email = email;
                existingUser.Phone = phone;
                return _context.SaveChanges();
            }
            else
            {
                return 0;
            }
        }

        public List<User> GetAllUsers(User loggedUser)
        {
            var query = from u in _context.Users
                        join c in _context.Connections on u.Id equals c.UserSendId
                        into joined
                        from j in joined.DefaultIfEmpty()
                        where j == null && j.UserSendId != loggedUser.Id && j.UserAcceptId != loggedUser.Id && j.ConnectionStatus == 0
                        select u;
            return query.ToList();
        }

        public User GetUserByName(string username)
        {
            return _context.Users.FirstOrDefault(u => u.UserName == username);
        }

        public int RequestConnection(Connection conn)
        {
            _context.Connections.Add(conn);
            return _context.SaveChanges();
        }
        public List<User> GetAllPendingUsers(User loggedUser)
        {
            var query = from t1 in _context.Users join t2 in _context.Connections on t1.Id equals t2.UserSendId
                        where t2.UserAcceptId == loggedUser.Id && t2.ConnectionStatus == 0
                        select new User
                        {
                            Id = t2.UserSendId,
                            FirstName = t1.FirstName,
                            LastName = t1.LastName,
                            Email = t1.Email,
                            Phone = t1.Phone,
                            UserName = t1.UserName,
                        };
            return query.ToList();
        }

        public int AcceptUser(User loggedUser, User user)
        {
            Connection? conn = _context.Connections.FirstOrDefault(u => u.UserSendId == user.Id && u.UserAcceptId == loggedUser.Id && u.ConnectionStatus == 0);
            conn.ConnectionStatus = 1;
            return _context.SaveChanges();
        }

        public int RejectUser(User loggedUser, User user)
        {
            Connection? conn = _context.Connections.FirstOrDefault(u => u.UserSendId == user.Id && u.UserAcceptId == loggedUser.Id && u.ConnectionStatus == 0);
            conn.ConnectionStatus = -1;
            return _context.SaveChanges();
        }

        public List<User> GetConnectedUsers(User loggedUser)
        {
            var query = from u in _context.Users
                    join c in _context.Connections on u.Id equals c.UserSendId into sendConnections
                    from sendConn in sendConnections.DefaultIfEmpty()
                    join c2 in _context.Connections on u.Id equals c2.UserAcceptId into acceptConnections
                    from acceptConn in acceptConnections.DefaultIfEmpty()
                    where (u.Id == sendConn.UserSendId && u.Id != sendConn.UserAcceptId && u.Id != loggedUser.Id)
                           || (u.Id == acceptConn.UserAcceptId && u.Id != acceptConn.UserSendId && u.Id != loggedUser.Id)
                           && (sendConn.ConnectionStatus == 1 || acceptConn.ConnectionStatus == 1)
                    select u;
            //var query = from u in _context.Users
            //            join c1 in _context.Connections on u.Id equals c1.UserSendId
            //            join c2 in _context.Connections on u.Id equals c2.UserAcceptId
            //            where (c1.UserAcceptId == loggedUser.Id && c1.UserSendId != loggedUser.Id)
            //            || (c1.UserAcceptId != loggedUser.Id && c1.UserSendId == loggedUser.Id)
            //            && c1.ConnectionStatus == 1
            //            select new User
            //            {
            //                Id = c1.UserSendId,
            //                FirstName = u.FirstName,
            //                LastName = u.LastName,
            //                Email = u.Email,
            //                Phone = u.Phone,
            //                UserName = u.UserName,
            //            };
            return query.ToList();
        }
    }
}
