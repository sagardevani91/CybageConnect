﻿using System;
using System.Collections.Generic;

namespace CybageConnect.Entity.DB;

public partial class User
{
    public int Id { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string UserName { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public int? IsActive { get; set; }

    public virtual ICollection<Article> Articles { get; set; } = new List<Article>();

    public virtual ICollection<Blog> Blogs { get; set; } = new List<Blog>();

    public virtual ICollection<Connection> ConnectionUserAccepts { get; set; } = new List<Connection>();

    public virtual ICollection<Connection> ConnectionUserSends { get; set; } = new List<Connection>();

    public virtual ICollection<ProjectInsight> ProjectInsights { get; set; } = new List<ProjectInsight>();
}
