﻿using System;
using System.Collections.Generic;

namespace CybageConnect.Entity.DB;

public partial class Blog
{
    public int Id { get; set; }

    public string BlogName { get; set; } = null!;

    public string BlogContent { get; set; } = null!;

    public DateTime BlogDate { get; set; }

    public int UserId { get; set; }

    public virtual User User { get; set; } = null!;
}
