﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CybageConnect.Entity.DB;

public partial class CybageConnectContext : DbContext
{
    public CybageConnectContext()
    {
    }

    public CybageConnectContext(DbContextOptions<CybageConnectContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Article> Articles { get; set; }

    public virtual DbSet<Blog> Blogs { get; set; }

    public virtual DbSet<Connection> Connections { get; set; }

    public virtual DbSet<ProjectInsight> ProjectInsights { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=SAGARDEV-GIFT\\MSSQLSERVER2019;database=CybageConnect;user id=sa;password=cybage@123456;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Article>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_Articles_1");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ArticleDate).HasColumnType("datetime");
            entity.Property(e => e.ArticleName).HasMaxLength(100);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany(p => p.Articles)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Articles_Users");
        });

        modelBuilder.Entity<Blog>(entity =>
        {
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.BlogDate).HasColumnType("datetime");
            entity.Property(e => e.BlogName).HasMaxLength(100);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany(p => p.Blogs)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Blogs_Blogs");
        });

        modelBuilder.Entity<Connection>(entity =>
        {
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ConnectionDate).HasColumnType("datetime");
            entity.Property(e => e.UserAcceptId).HasColumnName("UserAcceptID");
            entity.Property(e => e.UserSendId).HasColumnName("UserSendID");

            entity.HasOne(d => d.UserAccept).WithMany(p => p.ConnectionUserAccepts)
                .HasForeignKey(d => d.UserAcceptId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Connections_Users");

            entity.HasOne(d => d.UserSend).WithMany(p => p.ConnectionUserSends)
                .HasForeignKey(d => d.UserSendId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Connections_Connections");
        });

        modelBuilder.Entity<ProjectInsight>(entity =>
        {
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.InsightDate).HasColumnType("datetime");
            entity.Property(e => e.ProjectInsight1).HasColumnName("ProjectInsight");
            entity.Property(e => e.ProjectName).HasMaxLength(50);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany(p => p.ProjectInsights)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ProjectInsights_Users");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.IsActive).HasDefaultValue(0);
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Password).HasMaxLength(100);
            entity.Property(e => e.Phone).HasMaxLength(10);
            entity.Property(e => e.UserName).HasMaxLength(50);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
