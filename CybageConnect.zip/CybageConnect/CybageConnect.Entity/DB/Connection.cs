﻿using System;
using System.Collections.Generic;

namespace CybageConnect.Entity.DB;

public partial class Connection
{
    public int Id { get; set; }

    public int UserSendId { get; set; }

    public int UserAcceptId { get; set; }

    public string ConnectionStatus { get; set; } = null!;

    public DateTime ConnectionDate { get; set; }

    public virtual User UserAccept { get; set; } = null!;

    public virtual User UserSend { get; set; } = null!;
}
