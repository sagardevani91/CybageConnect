﻿using System;
using System.Collections.Generic;

namespace CybageConnect.Entity.DB;

public class ProjectInsight
{
    public int Id { get; set; }

    public string ProjectName { get; set; } = null!;

    public string ProjectInsight1 { get; set; } = null!;

    public DateTime InsightDate { get; set; }

    public int UserId { get; set; }

    public virtual User User { get; set; } = null!;
}
