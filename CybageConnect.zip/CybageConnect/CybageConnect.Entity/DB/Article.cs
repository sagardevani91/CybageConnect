﻿using System;
using System.Collections.Generic;

namespace CybageConnect.Entity.DB;

public partial class Article
{
    public int Id { get; set; }

    public string ArticleName { get; set; } = null!;

    public string ArticleContent { get; set; } = null!;

    public DateTime ArticleDate { get; set; }

    public int UserId { get; set; }

    public virtual User User { get; set; } = null!;
}
