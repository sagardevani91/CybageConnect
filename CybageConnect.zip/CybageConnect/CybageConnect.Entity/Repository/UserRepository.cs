﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Entity.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly CybageConnectContext _context;

        public UserRepository(CybageConnectContext context) 
        {
            _context = context;
        }

        public bool ValidateUser(string username, string password) 
        {
            return _context.Users.Any(u => u.UserName == username && u.Password == password);

            //if (user != null)
            //{
            //    Console.WriteLine("Login successful! Welcome, " + user.FirstName + "!"); 
            //}
            //else
            //{
            //    Console.WriteLine("Invalid username or password. Please try again.");
            //}
        }
        public void RegisterUser(User user)
        {
            if (_context.Users.Any(u => u.UserName == user.UserName))
            {
                Console.WriteLine("Username already exists. Please choose a different one.");
                return;
            }

            if (_context.Users.Any(u => u.Email == user.Email))
            {
                Console.WriteLine("Email Address already exists. Please choose a different one.");
                return;
            }

            if (_context.Users.Any(u => u.Phone == user.Phone))
            {
                Console.WriteLine("Phone Number already exists. Please choose a different one.");
                return;
            }
            _context.Users.Add(user);
            _context.SaveChanges();
            Console.WriteLine("Registration successful!");
        }

        public void FindUser(int id)
        {
            var user = _context.Users.FirstOrDefault(u=>u.Id == id);
            Console.WriteLine($"{user.Id} {user.Email} {user.Phone}");
        }
    }
}
