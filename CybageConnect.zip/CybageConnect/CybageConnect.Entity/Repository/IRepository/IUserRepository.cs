﻿using CybageConnect.Entity.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Entity.Repository.IRepository
{
    public interface IUserRepository
    {
        bool ValidateUser(string username, string password);
        void RegisterUser(User user);
        void FindUser(int id);
    }
}
