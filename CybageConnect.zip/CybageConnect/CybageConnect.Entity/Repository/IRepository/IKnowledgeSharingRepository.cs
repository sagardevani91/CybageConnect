﻿using CybageConnect.Entity.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Entity.Repository.IRepository
{
    public interface IKnowledgeSharingRepository
    {
        void AddBlogs(Blog blog);

        List<Blog> GetBlogs();
        void AddArticles(Article article);

        List<Article> GetArticles();
        void AddProjectInsights(ProjectInsight projectinsight);

        List<ProjectInsight> GetProjectInsights();
    }
}
