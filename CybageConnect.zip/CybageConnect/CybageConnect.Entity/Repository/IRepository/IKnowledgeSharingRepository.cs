﻿using CybageConnect.Entity.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Entity.Repository.IRepository
{
    public interface IKnowledgeSharingRepository
    {
        int AddBlogs(Blog blog);

        List<Blog> GetBlogs();
        int AddArticles(Article article);

        List<Article> GetArticles();
        int AddProjectInsights(ProjectInsight projectinsight);

        List<ProjectInsight> GetProjectInsights();
    }
}
