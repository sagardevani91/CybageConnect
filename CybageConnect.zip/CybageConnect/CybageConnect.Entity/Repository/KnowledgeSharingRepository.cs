﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Entity.Repository
{
    public class KnowledgeSharingRepository : IKnowledgeSharingRepository
    {
        private readonly CybageConnectContext _context;
        public KnowledgeSharingRepository(CybageConnectContext context)
        {
            _context = context;
        }
        public void AddBlogs(Blog blog)
        {
            if (_context.Blogs.Any(u => u.BlogName == blog.BlogName))
            {
                Console.WriteLine("Blog already exists. Please choose a different one.");
                return;
            }
            else
            {
                _context.Blogs.Add(blog);
                _context.SaveChanges();
                Console.WriteLine("Blog added successfully!");
            }

        }
        public List<Blog> GetBlogs()
        {
            return _context.Blogs.ToList();
        }
        public void AddArticles(Article article)
        {
            if (_context.Articles.Any(u => u.ArticleName == article.ArticleName))
            {
                Console.WriteLine("Article already exists. Please choose a different one.");
                return;
            }
            else
            {
                _context.Articles.Add(article);
                _context.SaveChanges();
                Console.WriteLine("Article added successfully!");
            }


        }

        public List<Article> GetArticles()
        {
            return _context.Articles.ToList();
        }

        public void AddProjectInsights(ProjectInsight projectinsight)
        {
            if (_context.ProjectInsights.Any(u => u.ProjectName == projectinsight.ProjectName))
            {
                Console.WriteLine("Article already exists. Please choose a different one.");
                return;
            }
            else
            {
                _context.ProjectInsights.Add(projectinsight);
                _context.SaveChanges();
                Console.WriteLine("ProjectInsight added successfully!");
            }

        }

        public List<ProjectInsight> GetProjectInsights()
        {
            return _context.ProjectInsights.ToList();
        }
    }
}
