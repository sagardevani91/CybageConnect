﻿using CybageConnect.Entity.DB;
using CybageConnect.Entity.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageConnect.Entity.Repository
{
    public class KnowledgeSharingRepository : IKnowledgeSharingRepository
    {
        private readonly CybageConnectContext _context;
        public KnowledgeSharingRepository(CybageConnectContext context)
        {
            _context = context;
        }
        public int AddBlogs(Blog blog)
        {
            if (_context.Blogs.Any(u => u.BlogName == blog.BlogName))
            {
                Console.WriteLine("Blog already exists. Please choose a different one.");
                return 0;
            }
            else
            {
                _context.Blogs.Add(blog);
                return _context.SaveChanges();
            }

        }
        public List<Blog> GetBlogs()
        {
            return _context.Blogs.ToList();
        }
        public int AddArticles(Article article)
        {
            if (_context.Articles.Any(u => u.ArticleName == article.ArticleName))
            {
                Console.WriteLine("Article already exists. Please choose a different one.");
                return 0;
            }
            else
            {
                _context.Articles.Add(article);
                return _context.SaveChanges();
            }
        }

        public List<Article> GetArticles()
        {
            return _context.Articles.ToList();
        }

        public int AddProjectInsights(ProjectInsight projectinsight)
        {
            if (_context.ProjectInsights.Any(u => u.ProjectName == projectinsight.ProjectName))
            {
                Console.WriteLine("Article already exists. Please choose a different one.");
                return 0;
            }
            else
            {
                _context.ProjectInsights.Add(projectinsight);
                return _context.SaveChanges();
            }
        }

        public List<ProjectInsight> GetProjectInsights()
        {
            return _context.ProjectInsights.ToList();
        }
    }
}
